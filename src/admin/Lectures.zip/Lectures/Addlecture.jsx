import React from "react";
import './Addlectures.css';

const AddLectures = () => {
    return (
        <div className="lecture-form-container">
            <form className="lecture-form">
                <h1 className="form-title">Add Lectures</h1>
                
                <div className="form-group">
                    <label>Select Package</label>
                    <select>
                        <option value="">Beginner</option>
                        <option value="">Advanced</option>
                        <option value="">Expert</option>
                        <option value="">Diamond</option>
                    </select>
                </div>

                <div className="form-group">
                    <label>Add Video Link</label>
                    <input type="text" placeholder="Enter lecture link..." />
                </div>

                <div className="button-group">
                    <button type="button" className="cancel-btn">Cancel</button>
                    <button type="submit" className="submit-btn">Submit</button>
                </div>
            </form>
        </div>
    );
}

export default AddLectures;
